export class Post {
    id:number;
    user:string;
    click:string;
    postName : string;
    postPrice : number;
    postDes : string;
    image:string;
    category:string;
    contact:number;
    email:string
}
