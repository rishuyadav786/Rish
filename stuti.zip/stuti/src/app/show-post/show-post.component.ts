import { Component, OnInit } from '@angular/core';
import { Post } from '../post';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-post',
  templateUrl: './show-post.component.html',
  styleUrls: ['./show-post.component.css']
})
export class ShowPostComponent implements OnInit {
post:Post=new Post()
  constructor(private newservice:CommonService,private router:Router) { }
posts
  ngOnInit() {
    this.newservice.GetPosts().subscribe((data) => this.posts = data)
    this.router.navigate(["showposts"])

  }
 
  descriptionClick(){
    this.router.navigate(['description'])
  }
}
