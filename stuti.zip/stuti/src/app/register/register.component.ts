import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';
import { Register } from '../register';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
register:Register=new Register()
temp
title="Buy N Sell @CAPGEMINI"
  constructor(private newService:CommonService,private router:Router) { }
  ngOnInit() {
 }
  onSave(users){
    //  [a-z.\s-]+[@]capgemini[.][a-z]+
    this.temp=1
    if(!this.register.name || !this.register.email || !this.register.username || !this.register.password ){
return alert("all fields are required")
    }
    else{
      this.newService.saveUser(users).subscribe(data=>{alert(data.data)})
      this.router.navigate([''])
        
    }
  }

}
