import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  searchText = '';
  transform(items: any, searchText: any, ele: any) {

    if (!items) return [];
    if (!searchText) return items;
    searchText = searchText.toLowerCase();
    ele = ele.toLowerCase();
    switch (ele) {
   
      case 'title': {
        return items.filter(items => {
          return items.postName.toLowerCase().includes(searchText);
        })
      }

      case 'category': {
        return items.filter(items => {
          return items.category.toLowerCase().includes(searchText);
        })
      }

      case 'mypost': {
        return items.filter(items => {
          return items.user.toString().includes(searchText);
        })
      }
    
    }
  }








}


// transform(items: any[], searchText: string): any[] {
//   if(!items) return [];
//   if(!searchText) return items;
// searchText = searchText.toLowerCase();
// return items.filter( it => {
//     return it.toLowerCase().includes(searchText);
//   });
//  }