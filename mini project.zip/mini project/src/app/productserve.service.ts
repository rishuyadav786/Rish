import { Injectable, Output, EventEmitter } from '@angular/core';
// import { Product } from './product';
// import { Http,Response} from '@angular/http';
// import { Observable } from 'rxjs/Observable';
// import 'rxjs/add/operator/map';
import { HttpClient } from '@angular/common/http'
import { Product } from './product';
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
// import { Product1 } from '../assets/product';
@Injectable()
export class ProductserveService {
  products: Product[] = [];
  product: Product = new Product();
  @Output() showProduct:EventEmitter<Product>=new EventEmitter<Product>();

  constructor(private http: Http) { }

  addpro(pro: Product): Observable<Product[]> {
    return this.http.post("http://localhost:3000/prod", pro).map((response: Response) => <Product[]>response.json());
    // console.log("service"+JSON.stringify(e))
    // this.products.push(e);
    // return this;
  }

  getProduct(): Observable<Product[]> {
    return this.http.get("http://localhost:3000/prod").map((response: Response) => <Product[]>response.json());
    // .map((resp:Response)=>resp.json());

  }
  removeproduct(proid: Number): Observable<Product[]> {
    return this.http.delete("http://localhost:3000/prod/" + proid).map((response: Response) => <Product[]>response.json()).catch(this.handleError);
  }
  handleError(error: Response) {
    console.error(error);
    return Observable.throw(error);
  }

  updatepro(pro: Product): Observable<Product[]> {
    return this.http.put(("http://localhost:3000/prod/" + pro.id), pro).map((response: Response) => <Product[]>response.json()).catch(this.handleError);
  }
  edit(pro: Product): void {
    //console.log("service");
    //Object.assign(this.products, pro);
    this.showProduct.emit(pro);

  }
  
}
