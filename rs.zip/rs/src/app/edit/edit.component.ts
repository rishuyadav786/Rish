import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Product } from '../product';
import { ProductserveService } from '../productserve.service'

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  product: Product = new Product();
  products: Product[] = [];


  constructor(private ProductserveService: ProductserveService) {

  }

  ngOnInit() {
    this.ProductserveService.showProduct.subscribe(res => {
      this.product = res;
    })
  }
  change():any
  {
  
    var categ = (document.getElementById("change") as HTMLInputElement).value;
    if(categ=="mobile"){
      (document.getElementById("ram") as HTMLInputElement).style.display="block";
      (document.getElementById("rom") as HTMLInputElement).style.display="block";
      (document.getElementById("battery") as HTMLInputElement).style.display="block";
      (document.getElementById("processor") as HTMLInputElement).style.display="block";
      (document.getElementById("length") as HTMLInputElement).style.display="block";
      (document.getElementById("color") as HTMLInputElement).style.display="block";
      (document.getElementById("others1") as HTMLInputElement).style.display="block";
 
    }
    if(categ=="tele"){
      (document.getElementById("length") as HTMLInputElement).style.display="block";
      (document.getElementById("ram") as HTMLInputElement).style.display="none";
      (document.getElementById("rom") as HTMLInputElement).style.display="none";
      (document.getElementById("battery") as HTMLInputElement).style.display="none";
      (document.getElementById("processor") as HTMLInputElement).style.display="none";
      (document.getElementById("others1") as HTMLInputElement).style.display="block";

}
if(categ=="cloths"){
  (document.getElementById("length") as HTMLInputElement).style.display="block";
  (document.getElementById("ram") as HTMLInputElement).style.display="none";
  (document.getElementById("rom") as HTMLInputElement).style.display="none";
  (document.getElementById("battery") as HTMLInputElement).style.display="none";
  (document.getElementById("processor") as HTMLInputElement).style.display="none";
  (document.getElementById("color") as HTMLInputElement).style.display="block";
  (document.getElementById("others1") as HTMLInputElement).style.display="block";


}
if(categ=="others"){
  (document.getElementById("length") as HTMLInputElement).style.display="none";
  (document.getElementById("ram") as HTMLInputElement).style.display="none";
  (document.getElementById("rom") as HTMLInputElement).style.display="none";
  (document.getElementById("battery") as HTMLInputElement).style.display="none";
  (document.getElementById("processor") as HTMLInputElement).style.display="none";
  (document.getElementById("others1") as HTMLInputElement).style.display="block";
  (document.getElementById("color") as HTMLInputElement).style.visibility="hidden";

}


  }
  edit(): void {
    var a = (document.getElementById("id") as HTMLInputElement).value;
    var b = (document.getElementById("name") as HTMLInputElement).value;
    var c = (document.getElementById("desc") as HTMLInputElement).value;
    var d = (document.getElementById("price") as HTMLInputElement).value;
    var regid = /^[0-9]+$/
    var regName = /^[A-Z][a-z]+$/
    if (a == "" || b == "" || c == "" || d == "") {
      alert("all field are required kindly add all data");

    }
    else {
      if (a.match(regid) && d.match(regid) && b.match(regName)) {
        this.ProductserveService.updatepro(this.product).subscribe((ProData) => this.ProductserveService.getProduct().subscribe((data) => this.products = data),
          (error) => {
            console.error(error);
          })
      }
      else {
        alert("please enter numeric value in id and price");
        alert("name field first letter should be capital letter ");
      }
    }
  }






}
